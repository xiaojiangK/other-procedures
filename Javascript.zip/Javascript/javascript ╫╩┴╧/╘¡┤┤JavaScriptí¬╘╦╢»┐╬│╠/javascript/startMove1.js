// JavaScript Document
function getStyle(obj,attr){
	if(obj.currentStyle){
		return obj.currentStyle[attr];
	}else{
		return 	getComputedStyle(obj,false)[attr];	
	}
}


function startMove(obj,attr,Taget,fun){
	
	clearInterval(obj.timer);
	
	obj.timer=setInterval(function(){
		
		//获取样式
		var iCur=0;

		//当传入进来的值为opacity,则单独处理该元素,否则当普通元素处理

		if (attr=="opacity") {
			iCur=parseInt(parseFloat(getStyle(obj,attr))*100);
		}else{
			iCur=parseInt(getStyle(obj,attr));
		}
		//速度大于0，则向上取整，否则向下取整。因为速度不能为小数点，如有小数点则会被清除，则导致Div距目标点差几像素
		var speed=(Taget-iCur)/8;	
		speed=speed>0?Math.ceil(speed):speed=Math.floor(speed);
	
		//获取到的样式等于Taget时清除定时器，否则继续执行代码
		if(iCur==Taget){
			clearInterval(obj.timer);	
			if (fun) {
				fun();
			};
		}else{

			//当样式为opacity就进行处理该元素,否则当普通元素进行处理
			if(attr=='opacity')
			{

			//进行字符串拼接,获取的对象样式+速度,火狐兼容版:获取到的对象样式/100
			obj.style.filter='alpha(opacity:'+(iCur+speed)+")";
			obj.style.opacity=(iCur+speed)/100;
			
			}else{
				obj.style[attr]=iCur+speed+"px";	
			}
		}
	},30)
}
