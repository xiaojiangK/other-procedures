<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<?php
class Person
{
	function __construct($name, $sex)
	{
		$this->name=$name;
		$this->sex=$sex;
	}
	
	function showName()
	{
		echo $this->name;
	}
	
	function showSex()
	{
		echo $this->sex;
	}
}

class Worker extends Person					//extends 代表Worker 是从 Person类的继承过来的
{
	function __construct($name, $sex, $job)	//构造函数,把父类的属性传过来
	{
		parent::__construct($name, $sex);	//执行父类的构造函数
		
		$this->job=$job;					//给Worker添加job属性
	}
		
	function showJob()						//给Worker添加showjob方法
	{
		echo $this->job;
	}
}

$w1=new Worker('blue', '男', '打杂的');		//new 一个Worker类

$w1->showName();							//执行从父类继承的shouName方法..
$w1->showJob();
?>
</body>
</html>